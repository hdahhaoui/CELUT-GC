
import { useState, useCallback } from 'react';

interface UseModalReturn {
  isModalOpen: boolean;
  openModal: () => void;
  closeModal: () => void;
}

export const useModal = (initialState: boolean = false): UseModalReturn => {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(initialState);

  const openModal = useCallback(() => {
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
  }, []);

  return { isModalOpen, openModal, closeModal };
};
    
import React from 'react';
import { Link } from 'react-router-dom';
import { useCompanies } from '../contexts/CompanyContext';
import { useTeachers } from '../contexts/TeacherContext';
import { useProjects } from '../contexts/ProjectContext';
import { useInternships } from '../contexts/InternshipContext';
import { ProjectStatus } from '../types';
import { Button } from '../components/ui/Button';
import { PlusIcon, BuildingOfficeIcon, AcademicCapIcon, LightBulbIcon, BriefcaseIcon } from '../constants';

const StatCard: React.FC<{ title: string; value: number | string; icon: React.ReactNode, linkTo: string, linkText: string }> = ({ title, value, icon, linkTo, linkText }) => (
  <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 flex flex-col justify-between">
    <div>
      <div className="flex items-center text-primary-dark mb-3">
        {icon}
        <h3 className="ml-3 text-lg font-semibold">{title}</h3>
      </div>
      <p className="text-4xl font-bold text-gray-800 mb-4">{value}</p>
    </div>
    <Link to={linkTo}>
      <Button variant="outline" size="sm" className="w-full mt-2">
        {linkText}
      </Button>
    </Link>
  </div>
);


export const HomePage: React.FC = () => {
  const { companies } = useCompanies();
  const { teachers } = useTeachers();
  const { projects } = useProjects();
  const { internships } = useInternships();

  const openProjectsCount = projects.filter(p => p.status === ProjectStatus.OPEN || p.status === ProjectStatus.PENDING_APPROVAL).length;
  const openInternshipsCount = internships.filter(i => i.status === ProjectStatus.OPEN || i.status === ProjectStatus.PENDING_APPROVAL).length;

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-primary to-secondary p-8 md:p-12 rounded-xl shadow-2xl text-white">
        <h1 className="text-4xl md:text-5xl font-bold mb-2">Bienvenue sur la plateforme CELUT-GC</h1>
        <p className="text-xl md:text-2xl font-semibold text-primary-light mb-4">
          <span className="block sm:inline">Connexion</span> 
          <span className="block sm:inline"> Entreprises<span className="text-white opacity-80">-</span>Laboratoires<span className="text-white opacity-80">-</span>Université de Tlemcen,</span>
          <span className="block sm:inline"> Département de Génie Civil.</span>
        </p>
        <p className="text-lg md:text-xl text-primary-light mb-6">Connecter le monde académique et les entreprises pour l'innovation en Génie Civil.</p>
        <div className="flex flex-wrap gap-4">
            <Link to="/projects">
                <Button variant="secondary" size="lg" leftIcon={<LightBulbIcon className="h-5 w-5"/>}>Voir les Projets</Button>
            </Link>
            <Link to="/internships">
                 <Button variant="outline" className="bg-white !text-primary hover:!bg-primary-light" size="lg" leftIcon={<BriefcaseIcon className="h-5 w-5"/>}>Trouver un Stage</Button>
            </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Entreprises Partenaires" value={companies.length} icon={<BuildingOfficeIcon className="h-8 w-8" />} linkTo="/companies" linkText="Gérer les Entreprises"/>
        <StatCard title="Enseignants Chercheurs" value={teachers.length} icon={<AcademicCapIcon className="h-8 w-8" />} linkTo="/teachers" linkText="Voir les Enseignants"/>
        <StatCard title="Projets Actifs" value={openProjectsCount} icon={<LightBulbIcon className="h-8 w-8" />} linkTo="/projects" linkText="Explorer les Projets"/>
        <StatCard title="Stages Disponibles" value={openInternshipsCount} icon={<BriefcaseIcon className="h-8 w-8" />} linkTo="/internships" linkText="Consulter les Stages"/>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-2xl font-semibold text-primary-dark mb-4">Actions Rapides</h2>
          <div className="space-y-3">
            <Link to="/projects#add"> {/* Assuming modals can be triggered by hash, or pages handle this */}
              <Button variant="primary" className="w-full" leftIcon={<PlusIcon className="h-5 w-5"/>}>Proposer un Projet</Button>
            </Link>
            <Link to="/internships#add">
              <Button variant="primary" className="w-full" leftIcon={<PlusIcon className="h-5 w-5"/>}>Publier un Stage</Button>
            </Link>
             <Link to="/companies#add">
              <Button variant="outline" className="w-full" leftIcon={<PlusIcon className="h-5 w-5"/>}>Ajouter une Entreprise</Button>
            </Link>
             <Link to="/teachers#add">
              <Button variant="outline" className="w-full" leftIcon={<PlusIcon className="h-5 w-5"/>}>Ajouter un Enseignant</Button>
            </Link>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-2xl font-semibold text-primary-dark mb-4">À Propos de la Plateforme</h2>
          <p className="text-gray-700 mb-3">
            Cette plateforme vise à faciliter la collaboration entre le département de Génie Civil et ses partenaires socio-économiques. Elle permet de centraliser les offres de projets, de stages, et de mettre en relation les acteurs clés pour favoriser l'innovation et l'insertion professionnelle.
          </p>
          <p className="text-gray-700">
            Explorez les différentes sections pour découvrir les opportunités et initier de nouvelles collaborations fructueuses.
          </p>
        </div>
      </div>
    </div>
  );
};
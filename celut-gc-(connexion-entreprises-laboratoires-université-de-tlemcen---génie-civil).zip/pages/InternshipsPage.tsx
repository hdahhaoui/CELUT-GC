
import React, { useState } from 'react';
import { useInternships } from '../contexts/InternshipContext';
import { useCompanies } from '../contexts/CompanyContext';
import { useTeachers } from '../contexts/TeacherContext';
import { InternshipCard } from '../components/InternshipCard';
import { Modal } from '../components/Modal';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Select } from '../components/ui/Select';
import { Label } from '../components/ui/Label';
import { PlusIcon } from '../constants';
import { NewInternship, ProjectStatus } from '../types';
import { useModal } from '../hooks/useModal';

const InternshipForm: React.FC<{ onClose: () => void; onSave: (internship: NewInternship) => void }> = ({ onClose, onSave }) => {
  const { companies } = useCompanies();
  const { teachers } = useTeachers();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [companyId, setCompanyId] = useState('');
  const [duration, setDuration] = useState('');
  const [solicitedTutorId, setSolicitedTutorId] = useState<string | undefined>(undefined);
  const [status, setStatus] = useState<ProjectStatus>(ProjectStatus.OPEN);
  const [location, setLocation] = useState('');
  const [skillsRequired, setSkillsRequired] = useState(''); // Comma-separated string

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !companyId || !duration || !location) {
        alert("Veuillez remplir tous les champs obligatoires: Titre, Description, Entreprise, Durée, Lieu.");
        return;
    }
    onSave({ 
        title, 
        description, 
        companyId, 
        duration, 
        solicitedTutorId, 
        status,
        location,
        skillsRequired: skillsRequired.split(',').map(s => s.trim()).filter(s => s),
    });
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="internshipTitle">Titre du stage *</Label>
        <Input id="internshipTitle" value={title} onChange={(e) => setTitle(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="internshipDescription">Description *</Label>
        <Textarea id="internshipDescription" value={description} onChange={(e) => setDescription(e.target.value)} required />
      </div>
       <div>
        <Label htmlFor="internshipCompany">Entreprise *</Label>
        <Select id="internshipCompany" value={companyId} onChange={(e) => setCompanyId(e.target.value)} required>
          <option value="">Sélectionner une entreprise...</option>
          {companies.map(company => (
            <option key={company.id} value={company.id}>{company.name}</option>
          ))}
        </Select>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <Label htmlFor="internshipDuration">Durée *</Label>
            <Input id="internshipDuration" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="Ex: 3-6 mois" required />
        </div>
        <div>
            <Label htmlFor="internshipLocation">Lieu *</Label>
            <Input id="internshipLocation" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Ex: Paris, France" required/>
        </div>
      </div>
      <div>
        <Label htmlFor="internshipSkills">Compétences requises (séparées par des virgules)</Label>
        <Input id="internshipSkills" value={skillsRequired} onChange={(e) => setSkillsRequired(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="internshipTutor">Solliciter un tuteur enseignant (Optionnel)</Label>
        <Select id="internshipTutor" value={solicitedTutorId || ''} onChange={(e) => setSolicitedTutorId(e.target.value || undefined)}>
          <option value="">Aucun tuteur spécifique</option>
          {teachers.map(teacher => (
            <option key={teacher.id} value={teacher.id}>{teacher.name}</option>
          ))}
        </Select>
      </div>
      <div>
        <Label htmlFor="internshipStatus">Statut</Label>
        <Select id="internshipStatus" value={status} onChange={(e) => setStatus(e.target.value as ProjectStatus)}>
          {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
        </Select>
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
        <Button type="submit">Enregistrer</Button>
      </div>
    </form>
  );
};

export const InternshipsPage: React.FC = () => {
  const { internships, addInternship } = useInternships();
  const { isModalOpen, openModal, closeModal } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>(''); // All statuses
  const [filterCompany, setFilterCompany] = useState<string>(''); // All companies
  const { companies } = useCompanies();


  const handleSaveInternship = (internship: NewInternship) => {
    addInternship(internship);
  };

  const filteredInternships = internships.filter(internship => 
    (internship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
     internship.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
     internship.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
     internship.skillsRequired.join(', ').toLowerCase().includes(searchTerm.toLowerCase()) ||
     internship.location.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterStatus === '' || internship.status === filterStatus) &&
    (filterCompany === '' || internship.companyId === filterCompany)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Offres de Stage</h1>
        <Button onClick={openModal} leftIcon={<PlusIcon className="h-5 w-5"/>}>
          Publier un Stage
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-white rounded-lg shadow">
          <Input 
            type="text"
            placeholder="Rechercher un stage..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="md:col-span-1"
          />
          <Select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="md:col-span-1">
            <option value="">Tous les statuts</option>
            {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </Select>
           <Select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} className="md:col-span-1">
            <option value="">Toutes les entreprises</option>
            {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </div>

      {filteredInternships.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredInternships.map(internship => (
            <InternshipCard key={internship.id} internship={internship} />
          ))}
        </div>
      ) : (
         <p className="text-center text-gray-500 py-10">Aucun stage trouvé. Essayez d'affiner vos filtres ou publiez une nouvelle offre.</p>
      )}

      <Modal isOpen={isModalOpen} onClose={closeModal} title="Publier une nouvelle offre de stage" size="2xl">
        <InternshipForm onClose={closeModal} onSave={handleSaveInternship} />
      </Modal>
    </div>
  );
};
    
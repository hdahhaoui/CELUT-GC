
import React, { useState } from 'react';
import { useProjects } from '../contexts/ProjectContext';
import { useCompanies } from '../contexts/CompanyContext';
import { useTeachers } from '../contexts/TeacherContext';
import { ProjectCard } from '../components/ProjectCard';
import { Modal } from '../components/Modal';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Select } from '../components/ui/Select';
import { Label } from '../components/ui/Label';
import { PlusIcon } from '../constants';
import { NewProjectProposal, ProjectStatus, SolicitedEntity } from '../types';
import { useModal } from '../hooks/useModal';

const ProjectForm: React.FC<{ onClose: () => void; onSave: (project: NewProjectProposal) => void }> = ({ onClose, onSave }) => {
  const { companies } = useCompanies();
  const { teachers } = useTeachers();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [postedBy, setPostedBy] = useState<'teacher' | 'company'>('teacher');
  const [posterId, setPosterId] = useState('');
  const [solicitedEntities, setSolicitedEntities] = useState<SolicitedEntity[]>([]);
  const [status, setStatus] = useState<ProjectStatus>(ProjectStatus.OPEN);
  const [keywords, setKeywords] = useState('');


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !posterId) {
        alert("Veuillez remplir tous les champs obligatoires: Titre, Description, Proposé par.");
        return;
    }
    onSave({ 
        title, 
        description, 
        postedBy, 
        posterId, 
        solicitedEntities, 
        status,
        keywords: keywords.split(',').map(k => k.trim()).filter(k => k)
    });
    onClose();
  };

  const handleSolicitationChange = (e: React.ChangeEvent<HTMLSelectElement>, type: 'company' | 'teacher') => {
    const selectedOptions = Array.from(e.target.selectedOptions).map(option => ({
        id: option.value,
        name: option.text,
        type: type
    }));
    
    // Filter out the other type before adding new ones
    const otherType = type === 'company' ? 'teacher' : 'company';
    const existingOtherTypeSolicitations = solicitedEntities.filter(entity => entity.type === otherType);

    setSolicitedEntities([...existingOtherTypeSolicitations, ...selectedOptions]);
  };


  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="projectTitle">Titre du projet *</Label>
        <Input id="projectTitle" value={title} onChange={(e) => setTitle(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="projectDescription">Description *</Label>
        <Textarea id="projectDescription" value={description} onChange={(e) => setDescription(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="projectKeywords">Mots-clés (séparés par des virgules)</Label>
        <Input id="projectKeywords" value={keywords} onChange={(e) => setKeywords(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="projectPostedBy">Proposé par (type) *</Label>
        <Select id="projectPostedBy" value={postedBy} onChange={(e) => {setPostedBy(e.target.value as 'teacher' | 'company'); setPosterId(''); setSolicitedEntities([]);}} required>
          <option value="teacher">Enseignant</option>
          <option value="company">Entreprise</option>
        </Select>
      </div>
      <div>
        <Label htmlFor="projectPosterId">{postedBy === 'teacher' ? 'Enseignant proposant' : 'Entreprise proposant'} *</Label>
        <Select id="projectPosterId" value={posterId} onChange={(e) => setPosterId(e.target.value)} required>
          <option value="">Sélectionner...</option>
          {(postedBy === 'teacher' ? teachers : companies).map(entity => (
            <option key={entity.id} value={entity.id}>{entity.name}</option>
          ))}
        </Select>
      </div>
      
      {postedBy === 'teacher' && companies.length > 0 && (
        <div>
          <Label htmlFor="solicitCompanies">Solliciter des entreprises (Ctrl+clic pour sélection multiple)</Label>
          <Select id="solicitCompanies" multiple value={solicitedEntities.filter(se => se.type === 'company').map(se => se.id)} onChange={(e) => handleSolicitationChange(e, 'company')} className="h-32">
            {companies.map(company => (
              <option key={company.id} value={company.id}>{company.name}</option>
            ))}
          </Select>
        </div>
      )}
      {postedBy === 'company' && teachers.length > 0 && (
         <div>
          <Label htmlFor="solicitTeachers">Solliciter des enseignants (Ctrl+clic pour sélection multiple)</Label>
          <Select id="solicitTeachers" multiple value={solicitedEntities.filter(se => se.type === 'teacher').map(se => se.id)} onChange={(e) => handleSolicitationChange(e, 'teacher')} className="h-32">
            {teachers.map(teacher => (
              <option key={teacher.id} value={teacher.id}>{teacher.name}</option>
            ))}
          </Select>
        </div>
      )}

      <div>
        <Label htmlFor="projectStatus">Statut</Label>
        <Select id="projectStatus" value={status} onChange={(e) => setStatus(e.target.value as ProjectStatus)}>
          {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
        </Select>
      </div>

      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
        <Button type="submit">Enregistrer</Button>
      </div>
    </form>
  );
};

export const ProjectsPage: React.FC = () => {
  const { projects, addProject } = useProjects();
  const { isModalOpen, openModal, closeModal } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>(''); // All statuses
  const [filterType, setFilterType] = useState<string>(''); // All types

  const handleSaveProject = (project: NewProjectProposal) => {
    addProject(project);
  };

  const filteredProjects = projects.filter(project => 
    (project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
     project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
     project.keywords.join(', ').toLowerCase().includes(searchTerm.toLowerCase()) ||
     project.posterName.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterStatus === '' || project.status === filterStatus) &&
    (filterType === '' || project.postedBy === filterType)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Propositions de Projets</h1>
        <Button onClick={openModal} leftIcon={<PlusIcon className="h-5 w-5"/>}>
          Proposer un Projet
        </Button>
      </div>

       <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-white rounded-lg shadow">
          <Input 
            type="text"
            placeholder="Rechercher un projet..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="md:col-span-1"
          />
          <Select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="md:col-span-1">
            <option value="">Tous les statuts</option>
            {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="md:col-span-1">
            <option value="">Tous les types (Proposé par)</option>
            <option value="teacher">Enseignant</option>
            <option value="company">Entreprise</option>
          </Select>
        </div>

      {filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 py-10">Aucun projet trouvé. Essayez d'affiner vos filtres ou proposez un nouveau projet.</p>
      )}

      <Modal isOpen={isModalOpen} onClose={closeModal} title="Proposer un nouveau projet" size="2xl">
        <ProjectForm onClose={closeModal} onSave={handleSaveProject} />
      </Modal>
    </div>
  );
};
    

import React, { useState } from 'react';
import { useCompanies } from '../contexts/CompanyContext';
import { CompanyCard } from '../components/CompanyCard';
import { Modal } from '../components/Modal';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Label } from '../components/ui/Label';
import { PlusIcon } from '../constants';
import { NewCompany } from '../types';
import { useModal } from '../hooks/useModal';

const CompanyForm: React.FC<{ onClose: () => void; onSave: (company: NewCompany) => void }> = ({ onClose, onSave }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [website, setWebsite] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [areaOfActivity, setAreaOfActivity] = useState('');
  const [logoUrl, setLogoUrl] = useState('');


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !description || !areaOfActivity) {
        alert("Veuillez remplir tous les champs obligatoires: Nom, Description, Domaine d'activité.");
        return;
    }
    onSave({ name, description, website, contactEmail, areaOfActivity, logoUrl });
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="companyName">Nom de l'entreprise *</Label>
        <Input id="companyName" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="companyDescription">Description *</Label>
        <Textarea id="companyDescription" value={description} onChange={(e) => setDescription(e.target.value)} required />
      </div>
       <div>
        <Label htmlFor="companyArea">Domaine d'activité *</Label>
        <Input id="companyArea" value={areaOfActivity} onChange={(e) => setAreaOfActivity(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="companyWebsite">Site Web</Label>
        <Input id="companyWebsite" type="url" value={website} onChange={(e) => setWebsite(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="companyEmail">Email de contact</Label>
        <Input id="companyEmail" type="email" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="companyLogo">URL du logo (Optionnel, ex: https://picsum.photos/200)</Label>
        <Input id="companyLogo" type="url" value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} placeholder="https://picsum.photos/seed/mynewco/200" />
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
        <Button type="submit">Enregistrer</Button>
      </div>
    </form>
  );
};


export const CompaniesPage: React.FC = () => {
  const { companies, addCompany } = useCompanies();
  const { isModalOpen, openModal, closeModal } = useModal();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSaveCompany = (company: NewCompany) => {
    addCompany(company);
  };

  const filteredCompanies = companies.filter(company => 
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.areaOfActivity.toLowerCase().includes(searchTerm.toLowerCase())
  );


  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Entreprises Partenaires</h1>
        <Button onClick={openModal} leftIcon={<PlusIcon className="h-5 w-5"/>}>
          Ajouter une Entreprise
        </Button>
      </div>

       <div className="mb-6">
          <Input 
            type="text"
            placeholder="Rechercher une entreprise par nom, description, domaine..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-lg w-full"
          />
        </div>

      {filteredCompanies.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCompanies.map(company => (
            <CompanyCard key={company.id} company={company} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 py-10">Aucune entreprise trouvée. Essayez d'affiner votre recherche ou ajoutez une nouvelle entreprise.</p>
      )}

      <Modal isOpen={isModalOpen} onClose={closeModal} title="Ajouter une nouvelle entreprise" size="xl">
        <CompanyForm onClose={closeModal} onSave={handleSaveCompany} />
      </Modal>
    </div>
  );
};
    
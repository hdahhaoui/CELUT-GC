
import React, { useState } from 'react';
import { useTeachers } from '../contexts/TeacherContext';
import { TeacherCard } from '../components/TeacherCard';
import { Modal } from '../components/Modal';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Label } from '../components/ui/Label';
import { PlusIcon } from '../constants';
import { NewTeacher } from '../types';
import { useModal } from '../hooks/useModal';

const TeacherForm: React.FC<{ onClose: () => void; onSave: (teacher: NewTeacher) => void }> = ({ onClose, onSave }) => {
  const [name, setName] = useState('');
  const [cvSummary, setCvSummary] = useState('');
  const [department, setDepartment] = useState('Génie Civil'); // Default
  const [email, setEmail] = useState('');
  const [specializations, setSpecializations] = useState(''); // Comma-separated string
  const [photoUrl, setPhotoUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
     if (!name || !cvSummary || !department) {
        alert("Veuillez remplir tous les champs obligatoires: Nom, Résumé CV, Département.");
        return;
    }
    onSave({ 
      name, 
      cvSummary, 
      department, 
      email, 
      specializations: specializations.split(',').map(s => s.trim()).filter(s => s),
      photoUrl 
    });
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="teacherName">Nom de l'enseignant *</Label>
        <Input id="teacherName" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="teacherCvSummary">Résumé du CV *</Label>
        <Textarea id="teacherCvSummary" value={cvSummary} onChange={(e) => setCvSummary(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="teacherDepartment">Département *</Label>
        <Input id="teacherDepartment" value={department} onChange={(e) => setDepartment(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="teacherEmail">Email</Label>
        <Input id="teacherEmail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="teacherSpecializations">Spécialisations (séparées par des virgules)</Label>
        <Input id="teacherSpecializations" value={specializations} onChange={(e) => setSpecializations(e.target.value)} />
      </div>
       <div>
        <Label htmlFor="teacherPhoto">URL de la photo (Optionnel, ex: https://picsum.photos/200)</Label>
        <Input id="teacherPhoto" type="url" value={photoUrl} onChange={(e) => setPhotoUrl(e.target.value)} placeholder="https://picsum.photos/seed/newteacher/200" />
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <Button type="button" variant="outline" onClick={onClose}>Annuler</Button>
        <Button type="submit">Enregistrer</Button>
      </div>
    </form>
  );
};

export const TeachersPage: React.FC = () => {
  const { teachers, addTeacher } = useTeachers();
  const { isModalOpen, openModal, closeModal } = useModal();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSaveTeacher = (teacher: NewTeacher) => {
    addTeacher(teacher);
  };

  const filteredTeachers = teachers.filter(teacher => 
    teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    teacher.cvSummary.toLowerCase().includes(searchTerm.toLowerCase()) ||
    teacher.specializations.join(', ').toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Enseignants & Chercheurs</h1>
        <Button onClick={openModal} leftIcon={<PlusIcon className="h-5 w-5"/>}>
          Ajouter un Enseignant
        </Button>
      </div>

      <div className="mb-6">
          <Input 
            type="text"
            placeholder="Rechercher un enseignant par nom, CV, spécialisation..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-lg w-full"
          />
        </div>

      {filteredTeachers.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTeachers.map(teacher => (
            <TeacherCard key={teacher.id} teacher={teacher} />
          ))}
        </div>
      ) : (
         <p className="text-center text-gray-500 py-10">Aucun enseignant trouvé. Essayez d'affiner votre recherche ou ajoutez un nouvel enseignant.</p>
      )}

      <Modal isOpen={isModalOpen} onClose={closeModal} title="Ajouter un nouvel enseignant" size="xl">
        <TeacherForm onClose={closeModal} onSave={handleSaveTeacher} />
      </Modal>
    </div>
  );
};
    
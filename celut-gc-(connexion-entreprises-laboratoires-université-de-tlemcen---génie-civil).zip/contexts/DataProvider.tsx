
import React from 'react';
import { CompanyProvider } from './CompanyContext';
import { TeacherProvider } from './TeacherContext';
import { ProjectProvider } from './ProjectContext';
import { InternshipProvider } from './InternshipContext';

interface DataProviderProps {
  children: React.ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  return (
    <CompanyProvider>
      <TeacherProvider>
        <ProjectProvider>
          <InternshipProvider>
            {children}
          </InternshipProvider>
        </ProjectProvider>
      </TeacherProvider>
    </CompanyProvider>
  );
};
    
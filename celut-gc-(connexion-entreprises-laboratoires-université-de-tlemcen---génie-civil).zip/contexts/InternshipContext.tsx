
import React, { createContext, useState, useContext, useCallback, ReactNode } from 'react';
import { Internship, NewInternship, ProjectStatus } from '../types';
import { useCompanies } from './CompanyContext';
import { useTeachers } from './TeacherContext';

interface InternshipContextType {
  internships: Internship[];
  addInternship: (internship: NewInternship) => void;
}

const InternshipContext = createContext<InternshipContextType | undefined>(undefined);

const initialInternships: Internship[] = [
  { id: 'int1', title: 'Stage Assistant Chef de Projet BTP', description: 'Participation au suivi de chantiers, gestion des plannings et des budgets.', companyId: 'comp1', companyName: 'InnovBuild Construction', companyLogoUrl: 'https://picsum.photos/seed/comp1/100/100', duration: '6 mois', solicitedTutorId: 'teach2', solicitedTutorName: 'Prof. Marc Petit', status: ProjectStatus.OPEN, creationDate: new Date(2023, 11, 1).toISOString(), location: 'Paris, France', skillsRequired: ['AutoCAD', 'Gestion de projet'] },
  { id: 'int2', title: 'Stage Ingénieur Calcul de Structure', description: 'Modélisation et calcul de structures métalliques et béton.', companyId: 'comp2', companyName: 'Structura Ingénierie', companyLogoUrl: 'https://picsum.photos/seed/comp2/100/100', duration: '4-6 mois', status: ProjectStatus.OPEN, creationDate: new Date(2023, 10, 25).toISOString(), location: 'Lyon, France', skillsRequired: ['Robot Structural Analysis', 'Eurocodes'] },
];

export const InternshipProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [internships, setInternships] = useState<Internship[]>(initialInternships);
  const { getCompanyById } = useCompanies();
  const { getTeacherById } = useTeachers();


  const addInternship = useCallback((internshipData: NewInternship) => {
    const company = getCompanyById(internshipData.companyId);
    const tutor = internshipData.solicitedTutorId ? getTeacherById(internshipData.solicitedTutorId) : undefined;

    const newInternship: Internship = {
      ...internshipData,
      id: crypto.randomUUID(),
      creationDate: new Date().toISOString(),
      companyName: company?.name || 'Entreprise Inconnue',
      companyLogoUrl: company?.logoUrl || 'https://picsum.photos/seed/defaultlogo/100/100',
      solicitedTutorName: tutor?.name,
    };
    setInternships(prev => [newInternship, ...prev]);
  }, [getCompanyById, getTeacherById]);

  return (
    <InternshipContext.Provider value={{ internships, addInternship }}>
      {children}
    </InternshipContext.Provider>
  );
};

export const useInternships = (): InternshipContextType => {
  const context = useContext(InternshipContext);
  if (!context) {
    throw new Error('useInternships must be used within an InternshipProvider');
  }
  return context;
};
    
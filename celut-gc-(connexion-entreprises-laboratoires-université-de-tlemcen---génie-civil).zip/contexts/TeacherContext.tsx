
import React, { createContext, useState, useContext, useCallback, ReactNode } from 'react';
import { Teacher, NewTeacher } from '../types';

interface TeacherContextType {
  teachers: Teacher[];
  addTeacher: (teacher: NewTeacher) => void;
  getTeacherById: (id: string) => Teacher | undefined;
}

const TeacherContext = createContext<TeacherContextType | undefined>(undefined);

const initialTeachers: Teacher[] = [
  { id: 'teach1', name: 'Dr. Aline Dubois', cvSummary: 'PhD en Génie Civil, spécialisée en matériaux de construction écologiques. 15 ans d\'expérience.', department: 'Génie Civil', photoUrl: 'https://picsum.photos/seed/teach1/200/200', email: 'aline.dubois@example.edu', specializations: ['Matériaux durables', 'Analyse structurelle'] },
  { id: 'teach2', name: 'Prof. Marc Petit', cvSummary: 'Expert en gestion de projets de construction et infrastructures urbaines. Auteur de plusieurs publications.', department: 'Génie Civil', photoUrl: 'https://picsum.photos/seed/teach2/200/200', email: 'marc.petit@example.edu', specializations: ['Gestion de projet', 'Infrastructures'] },
  { id: 'teach3', name: 'Dr. Sophie Bernard', cvSummary: 'Recherche axée sur la modélisation numérique et la simulation sismique des structures.', department: 'Génie Civil', photoUrl: 'https://picsum.photos/seed/teach3/200/200', email: 'sophie.bernard@example.edu', specializations: ['Modélisation numérique', 'Génie sismique'] },
];

export const TeacherProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [teachers, setTeachers] = useState<Teacher[]>(initialTeachers);

  const addTeacher = useCallback((teacherData: NewTeacher) => {
    const newTeacher: Teacher = {
      ...teacherData,
      id: crypto.randomUUID(),
      photoUrl: teacherData.photoUrl || `https://picsum.photos/seed/${crypto.randomUUID()}/200/200`,
    };
    setTeachers(prev => [...prev, newTeacher]);
  }, []);

  const getTeacherById = useCallback((id: string) => {
    return teachers.find(t => t.id === id);
  }, [teachers]);

  return (
    <TeacherContext.Provider value={{ teachers, addTeacher, getTeacherById }}>
      {children}
    </TeacherContext.Provider>
  );
};

export const useTeachers = (): TeacherContextType => {
  const context = useContext(TeacherContext);
  if (!context) {
    throw new Error('useTeachers must be used within a TeacherProvider');
  }
  return context;
};
    
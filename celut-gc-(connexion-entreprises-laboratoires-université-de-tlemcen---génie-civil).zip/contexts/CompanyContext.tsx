
import React, { createContext, useState, useContext, useCallback, ReactNode } from 'react';
import { Company, NewCompany } from '../types';

interface CompanyContextType {
  companies: Company[];
  addCompany: (company: NewCompany) => void;
  getCompanyById: (id: string) => Company | undefined;
}

const CompanyContext = createContext<CompanyContextType | undefined>(undefined);

const initialCompanies: Company[] = [
  { id: 'comp1', name: 'InnovBuild Construction', description: 'Leader en solutions de construction innovantes et durables.', logoUrl: 'https://picsum.photos/seed/comp1/200/200', website: 'https://innovbuild.example.com', contactEmail: 'contact@innovbuild.example.com', areaOfActivity: 'BTP, Génie Civil' },
  { id: 'comp2', name: 'Structura Ingénierie', description: 'Experts en conception et analyse structurelle.', logoUrl: 'https://picsum.photos/seed/comp2/200/200', website: 'https://structura.example.com', contactEmail: 'info@structura.example.com', areaOfActivity: 'Ingénierie des structures' },
  { id: 'comp3', name: 'TerraForm Solutions', description: 'Spécialistes en géotechnique et fondations.', logoUrl: 'https://picsum.photos/seed/comp3/200/200', contactEmail: 'projects@terraform.example.com', areaOfActivity: 'Géotechnique' },
];

export const CompanyProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [companies, setCompanies] = useState<Company[]>(initialCompanies);

  const addCompany = useCallback((companyData: NewCompany) => {
    const newCompany: Company = {
      ...companyData,
      id: crypto.randomUUID(),
      logoUrl: companyData.logoUrl || `https://picsum.photos/seed/${crypto.randomUUID()}/200/200`,
    };
    setCompanies(prev => [...prev, newCompany]);
  }, []);

  const getCompanyById = useCallback((id: string) => {
    return companies.find(c => c.id === id);
  }, [companies]);

  return (
    <CompanyContext.Provider value={{ companies, addCompany, getCompanyById }}>
      {children}
    </CompanyContext.Provider>
  );
};

export const useCompanies = (): CompanyContextType => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompanies must be used within a CompanyProvider');
  }
  return context;
};
    
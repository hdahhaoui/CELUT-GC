
import React, { createContext, useState, useContext, useCallback, ReactNode } from 'react';
import { ProjectProposal, NewProjectProposal, ProjectStatus } from '../types';
import { useCompanies } from './CompanyContext';
import { useTeachers } from './TeacherContext';

interface ProjectContextType {
  projects: ProjectProposal[];
  addProject: (project: NewProjectProposal) => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

const initialProjects: ProjectProposal[] = [
  { id: 'proj1', title: 'Optimisation des bétons fibrés', description: 'Recherche sur l\'amélioration des performances mécaniques des bétons fibrés pour applications structurelles.', postedBy: 'teacher', posterId: 'teach1', posterName: 'Dr. Aline Dubois', solicitedEntities: [{ id: 'comp1', name: 'InnovBuild Construction', type: 'company' }], status: ProjectStatus.OPEN, creationDate: new Date(2023, 10, 15).toISOString(), keywords: ['béton', 'matériaux', 'recherche'] },
  { id: 'proj2', title: 'Développement d\'une passerelle piétonne modulaire', description: 'Conception et étude de faisabilité d\'une passerelle piétonne innovante et facile à assembler.', postedBy: 'company', posterId: 'comp2', posterName: 'Structura Ingénierie', solicitedEntities: [{ id: 'teach2', name: 'Prof. Marc Petit', type: 'teacher' }], status: ProjectStatus.IN_PROGRESS, creationDate: new Date(2023, 9, 20).toISOString(), keywords: ['passerelle', 'structure', 'innovation'] },
];

export const ProjectProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [projects, setProjects] = useState<ProjectProposal[]>(initialProjects);
  const { getCompanyById } = useCompanies();
  const { getTeacherById } = useTeachers();

  const addProject = useCallback((projectData: NewProjectProposal) => {
    let posterName = 'N/A';
    if (projectData.postedBy === 'company') {
      posterName = getCompanyById(projectData.posterId)?.name || 'Entreprise Inconnue';
    } else {
      posterName = getTeacherById(projectData.posterId)?.name || 'Enseignant Inconnu';
    }

    const newProject: ProjectProposal = {
      ...projectData,
      id: crypto.randomUUID(),
      creationDate: new Date().toISOString(),
      posterName,
    };
    setProjects(prev => [newProject, ...prev]);
  }, [getCompanyById, getTeacherById]);

  return (
    <ProjectContext.Provider value={{ projects, addProject }}>
      {children}
    </ProjectContext.Provider>
  );
};

export const useProjects = (): ProjectContextType => {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProjects must be used within a ProjectProvider');
  }
  return context;
};
    
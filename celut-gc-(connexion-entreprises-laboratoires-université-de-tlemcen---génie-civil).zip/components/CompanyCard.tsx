
import React from 'react';
import { Company } from '../types';
import { ExternalLinkIcon, BriefcaseIcon, BuildingOfficeIcon } from '../constants';

interface CompanyCardProps {
  company: Company;
}

export const CompanyCard: React.FC<CompanyCardProps> = ({ company }) => {
  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative h-40 bg-gradient-to-r from-sky-500 to-cyan-500 flex items-center justify-center">
        <img 
            src={company.logoUrl} 
            alt={`${company.name} logo`} 
            className="h-24 w-24 rounded-full border-4 border-white object-cover shadow-md" 
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-primary-dark mb-2">{company.name}</h3>
        <p className="text-gray-600 text-sm mb-1 line-clamp-3">{company.description}</p>
         <div className="mt-3 mb-3 text-sm text-gray-500 flex items-center">
            <BriefcaseIcon className="h-5 w-5 mr-2 text-primary" />
            <span>{company.areaOfActivity}</span>
        </div>
        {company.website && (
          <a
            href={company.website}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-sm text-primary hover:text-primary-dark font-medium transition-colors duration-150"
          >
            Visiter le site <ExternalLinkIcon className="ml-1.5 h-4 w-4" />
          </a>
        )}
        {company.contactEmail && (
          <p className="text-sm text-gray-500 mt-2">
            Contact: <a href={`mailto:${company.contactEmail}`} className="text-primary hover:underline">{company.contactEmail}</a>
          </p>
        )}
      </div>
    </div>
  );
};
    
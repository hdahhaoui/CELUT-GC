
import React from 'react';
import { Teacher } from '../types';
import { AcademicCapIcon, TagIcon } from '../constants';

interface TeacherCardProps {
  teacher: Teacher;
}

export const TeacherCard: React.FC<TeacherCardProps> = ({ teacher }) => {
  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="p-6 flex items-start space-x-4">
        <img 
            src={teacher.photoUrl} 
            alt={`${teacher.name}`} 
            className="h-24 w-24 rounded-full border-2 border-primary object-cover shadow-sm" 
        />
        <div className="flex-1">
            <h3 className="text-xl font-semibold text-primary-dark mb-1">{teacher.name}</h3>
            <p className="text-sm text-secondary-dark font-medium mb-2">{teacher.department}</p>
            <p className="text-gray-600 text-sm mb-3 line-clamp-3">{teacher.cvSummary}</p>
        </div>
      </div>
      <div className="px-6 pb-4">
        {teacher.email && (
          <p className="text-sm text-gray-500 mb-2">
            Email: <a href={`mailto:${teacher.email}`} className="text-primary hover:underline">{teacher.email}</a>
          </p>
        )}
        {teacher.specializations && teacher.specializations.length > 0 && (
          <div>
            <h4 className="text-xs text-gray-500 uppercase font-semibold mb-1 flex items-center">
                <TagIcon className="h-4 w-4 mr-1 text-gray-400"/> Spécialisations
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {teacher.specializations.map((spec, index) => (
                <span key={index} className="px-2 py-0.5 bg-sky-100 text-sky-700 text-xs rounded-full">
                  {spec}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
    
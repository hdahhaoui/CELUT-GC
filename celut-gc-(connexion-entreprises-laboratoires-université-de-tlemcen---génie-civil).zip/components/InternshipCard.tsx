
import React from 'react';
import { Internship, ProjectStatus } from '../types';
import { BriefcaseIcon, MapPinIcon, AcademicCapIcon, TagIcon, CalendarDaysIcon } from '../constants';

interface InternshipCardProps {
  internship: Internship;
}

const StatusBadge: React.FC<{ status: ProjectStatus }> = ({ status }) => {
  let bgColor = 'bg-gray-100';
  let textColor = 'text-gray-800';

  switch (status) {
    case ProjectStatus.OPEN:
      bgColor = 'bg-green-100';
      textColor = 'text-green-800';
      break;
    case ProjectStatus.IN_PROGRESS: // Might not apply to internships but kept for consistency
      bgColor = 'bg-yellow-100';
      textColor = 'text-yellow-800';
      break;
    case ProjectStatus.CLOSED:
      bgColor = 'bg-red-100';
      textColor = 'text-red-800';
      break;
    case ProjectStatus.PENDING_APPROVAL:
       bgColor = 'bg-blue-100';
       textColor = 'text-blue-800';
      break;
  }
  return (
    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${bgColor} ${textColor}`}>
      {status}
    </span>
  );
};

export const InternshipCard: React.FC<InternshipCardProps> = ({ internship }) => {
  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col">
        <div className="p-6 flex-grow">
            <div className="flex items-start mb-3">
                <img src={internship.companyLogoUrl} alt={`${internship.companyName} logo`} className="h-16 w-16 mr-4 rounded-md object-contain border border-slate-200" />
                <div>
                    <div className="flex justify-between items-start">
                        <h3 className="text-xl font-semibold text-primary-dark mb-0.5 line-clamp-2">{internship.title}</h3>
                    </div>
                    <p className="text-sm text-secondary-dark font-medium">{internship.companyName}</p>
                </div>
                 <StatusBadge status={internship.status} />
            </div>
            
            <p className="text-gray-600 text-sm mb-4 line-clamp-3">{internship.description}</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm text-gray-600 mb-4">
                <div className="flex items-center">
                    <BriefcaseIcon className="h-5 w-5 mr-2 text-primary" />
                    <span>Durée: {internship.duration}</span>
                </div>
                <div className="flex items-center">
                    <MapPinIcon className="h-5 w-5 mr-2 text-primary" />
                    <span>Lieu: {internship.location}</span>
                </div>
            </div>

            {internship.skillsRequired && internship.skillsRequired.length > 0 && (
              <div className="mb-4">
                <h4 className="text-xs text-gray-500 uppercase font-semibold mb-1.5 flex items-center">
                    <TagIcon className="h-4 w-4 mr-1 text-gray-400"/> Compétences Requises
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {internship.skillsRequired.map((skill, index) => (
                    <span key={index} className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded-full">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {internship.solicitedTutorName && (
            <div className="flex items-center text-sm text-gray-500">
                <AcademicCapIcon className="h-5 w-5 mr-2 text-secondary" />
                <span>Tuteur sollicité: {internship.solicitedTutorName}</span>
            </div>
            )}
        </div>
         <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-xs text-gray-500 flex items-center justify-end">
            <CalendarDaysIcon className="h-4 w-4 mr-1.5 text-gray-400" />
            Publié le: {new Date(internship.creationDate).toLocaleDateString('fr-FR')}
        </div>
    </div>
  );
};

    
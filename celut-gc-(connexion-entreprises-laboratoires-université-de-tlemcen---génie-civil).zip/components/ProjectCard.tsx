
import React from 'react';
import { ProjectProposal, ProjectStatus } from '../types';
import { LightBulbIcon, BuildingOfficeIcon, AcademicCapIcon, TagIcon, CalendarDaysIcon } from '../constants';

interface ProjectCardProps {
  project: ProjectProposal;
}

const StatusBadge: React.FC<{ status: ProjectStatus }> = ({ status }) => {
  let bgColor = 'bg-gray-100';
  let textColor = 'text-gray-800';

  switch (status) {
    case ProjectStatus.OPEN:
      bgColor = 'bg-green-100';
      textColor = 'text-green-800';
      break;
    case ProjectStatus.IN_PROGRESS:
      bgColor = 'bg-yellow-100';
      textColor = 'text-yellow-800';
      break;
    case ProjectStatus.CLOSED:
      bgColor = 'bg-red-100';
      textColor = 'text-red-800';
      break;
    case ProjectStatus.PENDING_APPROVAL:
      bgColor = 'bg-blue-100';
      textColor = 'text-blue-800';
      break;
  }
  return (
    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${bgColor} ${textColor}`}>
      {status}
    </span>
  );
};

export const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  const PosterIcon = project.postedBy === 'company' ? BuildingOfficeIcon : AcademicCapIcon;
  
  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col">
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start mb-2">
            <h3 className="text-xl font-semibold text-primary-dark mb-1 line-clamp-2">{project.title}</h3>
            <StatusBadge status={project.status} />
        </div>
        <div className="flex items-center text-sm text-gray-500 mb-3">
            <PosterIcon className="h-5 w-5 mr-2 text-secondary" />
            <span>Proposé par: {project.posterName} ({project.postedBy === 'company' ? 'Entreprise' : 'Enseignant'})</span>
        </div>
        <p className="text-gray-600 text-sm mb-4 line-clamp-4">{project.description}</p>

        {project.keywords && project.keywords.length > 0 && (
          <div className="mb-4">
            <h4 className="text-xs text-gray-500 uppercase font-semibold mb-1.5 flex items-center">
                <TagIcon className="h-4 w-4 mr-1 text-gray-400"/> Mots-clés
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {project.keywords.map((keyword, index) => (
                <span key={index} className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs rounded-full">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
        )}
        
        {project.solicitedEntities && project.solicitedEntities.length > 0 && (
          <div>
            <h4 className="text-xs text-gray-500 uppercase font-semibold mb-1.5">Entités Sollicitées:</h4>
            <ul className="list-disc list-inside text-sm text-gray-600 space-y-0.5">
              {project.solicitedEntities.map(entity => (
                <li key={entity.id}>{entity.name} ({entity.type === 'company' ? 'Entreprise' : 'Enseignant'})</li>
              ))}
            </ul>
          </div>
        )}
      </div>
      <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-xs text-gray-500 flex items-center justify-end">
        <CalendarDaysIcon className="h-4 w-4 mr-1.5 text-gray-400" />
        Publié le: {new Date(project.creationDate).toLocaleDateString('fr-FR')}
      </div>
    </div>
  );
};
    
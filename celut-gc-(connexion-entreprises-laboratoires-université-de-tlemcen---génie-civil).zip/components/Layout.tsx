
import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { HomeIcon, BriefcaseIcon, AcademicCapIcon, LightBulbIcon, UserGroupIcon, BuildingOfficeIcon, FacebookIcon, LinkedInIcon, PhoneIcon } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

const navItems = [
  { name: 'Accueil', path: '/', icon: HomeIcon },
  { name: 'Entreprises', path: '/companies', icon: BuildingOfficeIcon },
  { name: 'Enseignants', path: '/teachers', icon: AcademicCapIcon },
  { name: 'Projets', path: '/projects', icon: LightBulbIcon },
  { name: 'Stages', path: '/internships', icon: BriefcaseIcon },
];

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-primary-dark shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <Link to="/" className="flex items-center">
              <UserGroupIcon className="h-10 w-10 text-primary-light" />
              <span className="ml-3 text-2xl font-bold text-white">CELUT-GC</span>
            </Link>
            <nav className="hidden md:flex space-x-2">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors duration-150 ease-in-out ${
                      isActive
                        ? 'bg-primary text-white'
                        : 'text-primary-light hover:text-white hover:bg-primary'
                    }`
                  }
                >
                  <item.icon className="h-5 w-5 mr-2" />
                  {item.name}
                </NavLink>
              ))}
            </nav>
          </div>
        </div>
      </header>
      
      {/* Mobile Navigation (placeholder, can be expanded) */}
      <nav className="md:hidden bg-primary-dark border-t border-primary p-2">
        <div className="flex justify-around">
        {navItems.map((item) => (
          <NavLink
            key={`mobile-${item.name}`}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center p-2 rounded-md text-xs font-medium transition-colors duration-150 ease-in-out ${
                isActive
                  ? 'text-white'
                  : 'text-primary-light hover:text-white'
              }`
            }
          >
            <item.icon className="h-5 w-5 mb-1" />
            {item.name}
          </NavLink>
        ))}
        </div>
      </nav>

      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="bg-slate-800 text-slate-300 py-8 text-center">
        <div className="container mx-auto px-4">
          <div className="mb-4">
            <p>&copy; {new Date().getFullYear()} CELUT-GC - Département Génie Civil, Université de Tlemcen. Tous droits réservés.</p>
          </div>
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-3 sm:space-y-0 sm:space-x-6">
            <a href="tel:+213000000000" // Replace with actual phone number
               aria-label="Contacter le département de Génie Civil par téléphone" 
               className="flex items-center hover:text-primary-light transition-colors">
              <PhoneIcon className="h-5 w-5 mr-2" />
              <span>+213 XXX XX XX XX</span> {/* Placeholder Phone Number */}
            </a>
            <div className="flex space-x-4">
              <a href="#facebook" // Replace with actual Facebook URL
                 target="_blank" 
                 rel="noopener noreferrer" 
                 aria-label="CELUT-GC sur Facebook"
                 className="hover:text-primary-light transition-colors">
                <FacebookIcon className="h-6 w-6" />
              </a>
              <a href="#linkedin" // Replace with actual LinkedIn URL
                 target="_blank" 
                 rel="noopener noreferrer" 
                 aria-label="CELUT-GC sur LinkedIn"
                 className="hover:text-primary-light transition-colors">
                <LinkedInIcon className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
